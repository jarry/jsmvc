<?php
/**
 * ע�����ݴ���
 * @author lichunping jarryli@gmail.com
 */
class CRegData
{
    function getNameList() {
		// test data
		$nameList = array('erik', 'allstart', 'jarry', 'baidu', 'google');
		return $nameList;
	}
}
?>
